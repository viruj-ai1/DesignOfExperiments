// src/screens/StatisticalAnalysis.tsx
import { useState, useEffect } from 'react'
import { BarChart, Bar, ScatterChart, Scatter, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, ResponsiveContainer, Cell } from 'recharts'
import { useStore } from '../store/useStore'
import { Analysis } from '../services/api'
import toast from 'react-hot-toast'

export default function StatisticalAnalysis() {
  const { currentProject, setStep, setAnalysis, analysisResults } = useStore()
  const rawResponses = currentProject?.responses || []
  const responses    = rawResponses.filter((r: any) => !['impurity b', 'impurity c'].includes(r.name.toLowerCase().trim()))
  const [selResp, setSelResp]   = useState(0)
  const [loading, setLoading]   = useState(false)

  const currentResponse = responses[selResp]
  const rawRespIdx      = currentResponse ? rawResponses.findIndex((r: any) => r.name === currentResponse.name) : selResp
  const targetIdx       = rawRespIdx >= 0 ? rawRespIdx : selResp
  const result          = analysisResults[targetIdx] || analysisResults[selResp]

  async function runAnalysis(idx: number) {
    if (!currentProject?.id) return
    setLoading(true)
    try {
      const runIdx = rawRespIdx >= 0 ? rawRespIdx : idx
      const data = await Analysis.run(currentProject.id, runIdx)
      setAnalysis(runIdx, data)
      toast.success('Analysis complete')
    } catch (e: any) {
      toast.error(e.response?.data?.detail || 'Analysis failed')
    } finally { setLoading(false) }
  }

  useEffect(() => {
    if (currentProject?.id) {
      Analysis.get(currentProject.id).then((saved: any[]) => {
        saved.forEach(a => {
          if (a.anova && Object.keys(a.anova).length > 0) {
            setAnalysis(a.response_idx, a)
          }
        })
        if (!analysisResults[targetIdx]) {
          runAnalysis(targetIdx)
        }
      }).catch(() => {
        if (!analysisResults[targetIdx]) {
          runAnalysis(targetIdx)
        }
      })
    }
  }, [currentProject?.id, selResp, targetIdx])


  const anova    = result?.anova
  const rsm      = result?.rsm
  const desc     = result?.descriptive

  // Pareto chart data
  const paretoData = anova?.rows?.slice(0,12)?.map((r: any) => ({
    term: r.term, effect: Math.abs(r.effect),
    significant: r.significant
  })) || []

  const CustomTooltip = ({ active, payload, label }: any) =>
    active && payload?.length ? (
      <div style={{ background:'var(--bg-elevated)', border:'1px solid var(--border)', borderRadius:8, padding:'0.6rem 0.85rem', fontSize:'0.8rem' }}>
        <div style={{ fontWeight:700, marginBottom:'0.3rem' }}>{label}</div>
        <div>Effect: <strong>{payload[0]?.value?.toFixed(4)}</strong></div>
      </div>
    ) : null

  return (
    <div>
      <div className="page-header">
        <div className="page-header-tag">Step 13</div>
        <h1 className="page-title">Statistical Analysis</h1>
        <p className="page-desc">Analyze the results to understand which factors affect the outcome.</p>
      </div>

      {/* Response selector */}
      <div style={{ display:'flex', gap:'0.5rem', marginBottom:'1.5rem', flexWrap:'wrap' }}>
        {responses.map((r: any, i: number) => (
          <button key={i} className={`btn ${selResp===i ? 'btn-primary' : 'btn-secondary'} btn-sm`}
            onClick={() => setSelResp(i)}>
            {r.name}
          </button>
        ))}
        <button className="btn btn-accent btn-sm" onClick={() => runAnalysis(selResp)} disabled={loading}>
          {loading ? <><div className="spinner"/>Running…</> : '↺ Re-analyze'}
        </button>
      </div>

      {loading && <div className="loading-overlay"><div className="spinner" /> Running statistical analysis…</div>}

      {result && !loading && (
        <>
          {/* Descriptive stats */}
          {desc && (
            <div className="grid-4 mb-2">
              {[{l:'Mean', v: desc.y_mean}, {l:'Std Dev', v: desc.y_std}, {l:'Min', v: desc.y_min}, {l:'Max', v: desc.y_max}].map(s => (
                <div key={s.l} className="stat-card">
                  <div className="stat-label">{s.l}</div>
                  <div className="stat-value" style={{ fontSize:'1.3rem' }}>{s.v?.toFixed(3)}</div>
                </div>
              ))}
            </div>
          )}

          <div className="grid-2" style={{ gap:'1.25rem' }}>
            {/* ANOVA Table */}
            {anova && !anova.error && anova.rows && (
              <div className="card">
                <div className="flex-between mb-2">
                  <div className="card-title">ANOVA Results</div>
                  <div style={{ display:'flex', gap:'0.5rem' }}>
                    <span className="badge badge-primary">R² = {anova.R2}</span>
                    <span className="badge badge-accent">n = {anova.n}</span>
                  </div>
                </div>
                <div style={{ overflowX:'auto' }}>
                  <table className="data-table">
                    <thead><tr><th>Term</th><th>Effect</th><th>F</th><th>p-value</th><th>Sig.</th></tr></thead>
                    <tbody>
                      {anova.rows?.slice(0,12).map((r: any, i: number) => (
                        <tr key={i} className={r.significant ? 'sig-row' : ''}>
                          <td className="mono">{r.term}</td>
                          <td className="mono">{r.effect?.toFixed(4)}</td>
                          <td className="mono">{r.F?.toFixed(2)}</td>
                          <td className="mono">{r.p_value?.toFixed(4)}</td>
                          <td>{r.significant && <span className="sig-badge">★</span>}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Pareto Chart */}
            {paretoData.length > 0 && (
              <div className="chart-wrap">
                <div className="chart-title">Pareto Chart of Effects</div>
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={paretoData} layout="vertical" margin={{ left:80, right:20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis type="number" tick={{ fill:'var(--text-muted)', fontSize:10 }} />
                    <YAxis type="category" dataKey="term" tick={{ fill:'var(--text-secondary)', fontSize:10 }} />
                    <Tooltip content={<CustomTooltip/>} />
                    <Bar dataKey="effect" radius={[0,4,4,0]}>
                      {paretoData.map((entry: any, i: number) => (
                        <Cell key={i} fill={entry.significant ? 'var(--success)' : 'var(--primary)'} opacity={0.85} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
                <div style={{ display:'flex', gap:'1rem', fontSize:'0.72rem', color:'var(--text-muted)', marginTop:'0.5rem' }}>
                  <span><span style={{ display:'inline-block', width:10, height:10, background:'var(--success)', borderRadius:2, marginRight:4 }}/>Significant (p&lt;0.05)</span>
                  <span><span style={{ display:'inline-block', width:10, height:10, background:'var(--primary)', borderRadius:2, marginRight:4 }}/>Not significant</span>
                </div>
              </div>
            )}
          </div>

          {/* RSM Coefficients & Lack of Fit */}
          {rsm && !rsm.error && rsm.converged && (
            <div className="card mt-2">
              <div className="flex-between mb-2" style={{ flexWrap: 'wrap', gap: '0.5rem' }}>
                <div className="card-title">RSM Quadratic Regression Model & Diagnostics</div>
                <div style={{ display:'flex', gap:'0.5rem', flexWrap: 'wrap' }}>
                  <span className="badge badge-primary">R² = {rsm.R2}</span>
                  <span className="badge badge-warning">R²adj = {rsm.R2_adj}</span>
                  {result.diagnostics?.pred_r2 !== undefined && (
                    <span className="badge badge-success">R²pred = {result.diagnostics.pred_r2}</span>
                  )}
                  {result.diagnostics?.press !== undefined && (
                    <span className="badge badge-accent">PRESS = {result.diagnostics.press}</span>
                  )}
                </div>
              </div>

              {/* Lack-of-Fit test summary */}
              {result.diagnostics?.lack_of_fit && (
                <div style={{ margin: '0.75rem 0', padding: '0.75rem', background: 'rgba(255,255,255,0.02)', borderRadius: '6px', border: '1px solid rgba(255,255,255,0.08)' }}>
                  <div style={{ fontWeight: 700, fontSize: '0.85rem', color: 'var(--primary-light)', marginBottom: '4px' }}>
                    Lack-of-Fit Test (Model Fit Check)
                  </div>
                  <div style={{ display: 'flex', gap: '1.5rem', fontSize: '0.8rem', flexWrap: 'wrap' }}>
                    <div>LOF F-Statistic: <strong>{result.diagnostics.lack_of_fit.f_stat ?? 'N/A'}</strong></div>
                    <div>p-value: <strong>{result.diagnostics.lack_of_fit.p_value ?? 'N/A'}</strong></div>
                    <div>
                      Fit Status:{' '}
                      <span className={`badge ${result.diagnostics.lack_of_fit.significant_lack_of_fit ? 'badge-danger' : 'badge-success'}`}>
                        {result.diagnostics.lack_of_fit.significant_lack_of_fit ? 'Significant Lack of Fit (Poor Fit)' : 'No Significant Lack of Fit (Good Fit)'}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              <div style={{ overflowX:'auto' }}>
                <table className="data-table">
                  <thead><tr><th>Term</th><th>Coefficient</th><th>Std. Error</th><th>t-value</th><th>p-value</th><th>Sig.</th></tr></thead>
                  <tbody>
                    {rsm.coefficients?.map((c: any, i: number) => (
                      <tr key={i} className={c.significant ? 'sig-row' : ''}>
                        <td className="mono">{c.term}</td>
                        <td className="mono">{c.coeff?.toFixed(4)}</td>
                        <td className="mono">{c.se?.toFixed(4)}</td>
                        <td className="mono">{c.t_value?.toFixed(3)}</td>
                        <td className="mono">{c.p_value?.toFixed(4)}</td>
                        <td>{c.significant && <span className="sig-badge">★</span>}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 4-in-1 Residual Diagnostic Plots */}
          {(() => {
            const diag = result?.diagnostics || {}
            const fittedArr: number[] = diag.fitted || result?.rsm?.y_pred || []
            const residsArr: number[] = diag.residuals || result?.rsm?.residuals || []
            const studentizedArr: number[] = diag.studentized || residsArr

            if (fittedArr.length === 0 && residsArr.length === 0) {
              return (
                <div className="card mt-2 flex-center" style={{ padding: '2rem', color: 'var(--text-muted)', textAlign: 'center' }}>
                  Diagnostic plots require fitted regression models. Click ↺ Re-analyze above to compute residual diagnostics.
                </div>
              )
            }

            // 1. Residuals vs Fitted
            const resVsFittedData = fittedArr.map((f: number, i: number) => ({
              fitted: Number(f.toFixed(2)),
              residual: Number((studentizedArr[i] ?? residsArr[i] ?? 0).toFixed(3))
            }))

            // 2. Normal Probability Plot (Q-Q)
            let qqData: any[] = []
            if (diag.qq_theoretical && diag.qq_theoretical.length > 0 && diag.qq_sample && diag.qq_sample.length > 0) {
              qqData = diag.qq_theoretical.map((q: number, i: number) => ({
                theoretical: Number(q.toFixed(3)),
                sample: Number((diag.qq_sample[i] ?? 0).toFixed(3))
              }))
            } else if (residsArr.length > 0) {
              const sorted = [...residsArr].sort((a, b) => a - b)
              const n = sorted.length
              qqData = sorted.map((r: number, i: number) => {
                const p = (i + 0.5) / n
                const t = Math.sqrt(-2 * Math.log(p < 0.5 ? p : 1 - p))
                const num = 2.515517 + t * (0.802853 + t * 0.010328)
                const den = 1 + t * (1.432788 + t * (0.189269 + t * 0.001308))
                const q = p < 0.5 ? -(t - num / den) : (t - num / den)
                return { theoretical: Number(q.toFixed(3)), sample: Number(r.toFixed(3)) }
              })
            }

            // 3. Residuals vs Run Order
            const orderData = (diag.res_vs_order && diag.res_vs_order.length > 0)
              ? diag.res_vs_order
              : residsArr.map((r: number, i: number) => ({ run_order: i + 1, residual: Number(r.toFixed(3)) }))

            // 4. Cook's Distance
            const cooksData = ((diag.cooks_d && diag.cooks_d.length > 0) ? diag.cooks_d : residsArr.map(() => 0)).map((c: number, i: number) => ({
              run: `R${i + 1}`,
              cooks: Number(c.toFixed(4))
            }))

            return (
              <div className="card mt-2" style={{ padding: '1.25rem' }}>
                <div className="card-title mb-2">4-in-1 Model Diagnostic Plots</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem' }}>
                  {/* 1. Residuals vs Fitted */}
                  <div style={{ background: 'rgba(255,255,255,0.02)', padding: '0.85rem', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.05)', minWidth: 0, height: 230 }}>
                    <div style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-muted)', marginBottom: '0.5rem' }}>Residuals vs Fitted Values</div>
                    <ResponsiveContainer width="100%" height={180}>
                      <ScatterChart margin={{ top: 10, right: 15, bottom: 15, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                        <XAxis type="number" dataKey="fitted" name="Fitted Value" tick={{ fill:'var(--text-muted)', fontSize:9 }} label={{ value: 'Fitted Value', position: 'insideBottom', offset: -10, fill: 'var(--text-muted)', fontSize: 9 }} domain={['auto', 'auto']} />
                        <YAxis type="number" dataKey="residual" name="Residual" tick={{ fill:'var(--text-muted)', fontSize:9 }} label={{ value: 'Residual', angle: -90, position: 'insideLeft', fill: 'var(--text-muted)', fontSize: 9 }} domain={['auto', 'auto']} />
                        <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                        <ReferenceLine y={0} stroke="var(--accent)" strokeDasharray="3 3" />
                        <Scatter data={resVsFittedData} fill="#6366f1" />
                      </ScatterChart>
                    </ResponsiveContainer>
                  </div>

                  {/* 2. Normal Probability Plot */}
                  <div style={{ background: 'rgba(255,255,255,0.02)', padding: '0.85rem', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.05)', minWidth: 0, height: 230 }}>
                    <div style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-muted)', marginBottom: '0.5rem' }}>Normal Probability Plot</div>
                    <ResponsiveContainer width="100%" height={180}>
                      <ScatterChart margin={{ top: 10, right: 15, bottom: 15, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                        <XAxis type="number" dataKey="theoretical" name="Theoretical Quantile" tick={{ fill:'var(--text-muted)', fontSize:9 }} label={{ value: 'Theoretical Quantile', position: 'insideBottom', offset: -10, fill: 'var(--text-muted)', fontSize: 9 }} domain={['auto', 'auto']} />
                        <YAxis type="number" dataKey="sample" name="Sample Quantile" tick={{ fill:'var(--text-muted)', fontSize:9 }} label={{ value: 'Sample Quantile', angle: -90, position: 'insideLeft', fill: 'var(--text-muted)', fontSize: 9 }} domain={['auto', 'auto']} />
                        <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                        <ReferenceLine segment={[{ x: -2.5, y: -2.5 }, { x: 2.5, y: 2.5 }]} stroke="var(--success)" strokeDasharray="3 3" />
                        <Scatter data={qqData} fill="#10b981" />
                      </ScatterChart>
                    </ResponsiveContainer>
                  </div>

                  {/* 3. Residuals vs Run Order */}
                  <div style={{ background: 'rgba(255,255,255,0.02)', padding: '0.85rem', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.05)', minWidth: 0, height: 230 }}>
                    <div style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-muted)', marginBottom: '0.5rem' }}>Residuals vs Run Order</div>
                    <ResponsiveContainer width="100%" height={180}>
                      <LineChart data={orderData} margin={{ top: 10, right: 15, bottom: 15, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                        <XAxis dataKey="run_order" tick={{ fill:'var(--text-muted)', fontSize:9 }} label={{ value: 'Run Order', position: 'insideBottom', offset: -10, fill: 'var(--text-muted)', fontSize: 9 }} />
                        <YAxis tick={{ fill:'var(--text-muted)', fontSize:9 }} label={{ value: 'Residual', angle: -90, position: 'insideLeft', fill: 'var(--text-muted)', fontSize: 9 }} domain={['auto', 'auto']} />
                        <Tooltip />
                        <ReferenceLine y={0} stroke="var(--accent)" strokeDasharray="3 3" />
                        <Line type="monotone" dataKey="residual" stroke="#f59e0b" strokeWidth={2} dot={{ r: 3, fill: '#f59e0b' }} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>

                  {/* 4. Cook's Distance */}
                  <div style={{ background: 'rgba(255,255,255,0.02)', padding: '0.85rem', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.05)', minWidth: 0, height: 230 }}>
                    <div style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-muted)', marginBottom: '0.5rem' }}>Cook's Distance (Influential Points)</div>
                    <ResponsiveContainer width="100%" height={180}>
                      <BarChart data={cooksData} margin={{ top: 10, right: 15, bottom: 15, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                        <XAxis dataKey="run" tick={{ fill:'var(--text-muted)', fontSize:9 }} />
                        <YAxis tick={{ fill:'var(--text-muted)', fontSize:9 }} label={{ value: "Cook's D", angle: -90, position: 'insideLeft', fill: 'var(--text-muted)', fontSize: 9 }} />
                        <Tooltip />
                        <ReferenceLine y={4 / (residsArr.length || 15)} stroke="var(--danger)" strokeDasharray="3 3" />
                        <Bar dataKey="cooks" fill="var(--danger)" radius={[3, 3, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            )
          })()}

        </>
      )}

      {result?.error && (
        <div className="alert alert-warning">{result.error}</div>
      )}

      <div className="step-nav">
        <button className="btn btn-secondary" onClick={() => setStep('upload-results')}>← Back</button>
        <button className="btn btn-primary" onClick={() => setStep('rsm')} disabled={!result}>
          View Response Surface →
        </button>
      </div>
    </div>
  )
}
