// src/screens/RSM.tsx  –  Response Surface Model & Contour
import { useState, useEffect } from 'react'
import { ScatterChart, Scatter, XAxis, YAxis, ZAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, ReferenceLine } from 'recharts'
import { useStore } from '../store/useStore'
import { Analysis } from '../services/api'
import toast from 'react-hot-toast'

export default function RSM() {
  const { currentProject, analysisResults, experiments, setStep } = useStore()
  const factors   = currentProject?.factors   || []
  const rawResponses = currentProject?.responses || []
  const responses    = rawResponses.filter((r: any) => !['impurity b', 'impurity c'].includes(r.name.toLowerCase().trim()))

  const [selResp, setSelResp]   = useState(0)
  const [factX, setFactX]       = useState(0)
  const [factY, setFactY]       = useState(Math.min(1, factors.length-1))
  const [contour, setContour]   = useState<any>(null)
  const [loading, setLoading]   = useState(false)

  const [activeTab, setActiveTab] = useState<'contour' | 'overlay' | 'monte-carlo'>('contour')
  const [overlayData, setOverlayData] = useState<any>(null)
  const [monteCarloData, setMonteCarloData] = useState<any>(null)
  const [loadingOverlay, setLoadingOverlay] = useState(false)
  const [loadingMC, setLoadingMC] = useState(false)

  const currentResponse = responses[selResp]
  const targetIdx       = currentResponse ? rawResponses.findIndex((r: any) => r.name === currentResponse.name) : selResp

  async function loadContour() {
    if (factors.length < 2 || !currentProject?.id) return
    setLoading(true)
    try {
      const data = await Analysis.contour(currentProject.id, targetIdx >= 0 ? targetIdx : selResp, factX, factY)
      setContour(data)
    } catch (e: any) {
      toast.error(e.response?.data?.detail || 'Contour failed. Run analysis first.')
    } finally { setLoading(false) }
  }

  async function loadOverlay() {
    if (factors.length < 2 || !currentProject) return
    setLoadingOverlay(true)
    try {
      const data = await Analysis.overlay(currentProject.id, factX, factY)
      setOverlayData(data)
    } catch (e: any) {
      console.error(e)
    } finally { setLoadingOverlay(false) }
  }

  async function loadMonteCarlo() {
    if (factors.length < 2 || !currentProject) return
    setLoadingMC(true)
    try {
      const stds = factors.map(() => 0.05) // 5% std dev in coded scale
      const data = await Analysis.monteCarlo(currentProject.id, stds, 5000, factX, factY)
      setMonteCarloData(data)
    } catch (e: any) {
      console.error(e)
    } finally { setLoadingMC(false) }
  }

  useEffect(() => {
    if (currentProject?.id) {
      const idxToUse = targetIdx >= 0 ? targetIdx : selResp
      Analysis.get(currentProject.id).then((saved: any[]) => {
        saved.forEach(a => {
          if (a.anova || a.rsm || a.regression) {
            useStore.getState().setAnalysis(a.response_idx, a)
          }
        })
        if (!analysisResults[idxToUse]) {
          Analysis.run(currentProject.id, idxToUse).then(data => {
            useStore.getState().setAnalysis(idxToUse, data)
          }).catch(console.error)
        }
      }).catch(() => {
        if (!analysisResults[idxToUse]) {
          Analysis.run(currentProject.id, idxToUse).then(data => {
            useStore.getState().setAnalysis(idxToUse, data)
          }).catch(console.error)
        }
      })
    }
  }, [currentProject?.id, selResp, targetIdx])

  useEffect(() => {
    loadContour()
    if (activeTab === 'overlay') loadOverlay()
    if (activeTab === 'monte-carlo') loadMonteCarlo()
  }, [selResp, targetIdx, factX, factY, activeTab])

  const activeAnalysis = analysisResults[targetIdx >= 0 ? targetIdx : selResp] || analysisResults[selResp]
  const rsm    = activeAnalysis?.rsm || activeAnalysis?.regression
  const diag   = activeAnalysis?.diagnostics

  // Build observed vs predicted data
  const respIdxToUse = targetIdx >= 0 ? targetIdx : selResp
  const obsPred = experiments
    .filter(e => e.result_values && e.result_values[respIdxToUse] != null)
    .map((e, index) => ({
      observed:  e.result_values![respIdxToUse],
      predicted: rsm?.y_pred?.[index] ?? null
    }))
    .filter(d => d.predicted !== null)

  return (
    <div>
      <div className="page-header">
        <div className="page-header-tag">Step 14</div>
        <h1 className="page-title">Response Surface</h1>
        <p className="page-desc">See how different settings affect the results and find the best range.</p>
      </div>

      {/* View Mode Tabs */}
      <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.25rem' }}>
        <button
          className={`btn ${activeTab === 'contour' ? 'btn-primary' : 'btn-secondary'} btn-sm`}
          onClick={() => setActiveTab('contour')}
        >
          2D Contour Surface
        </button>
        <button
          className={`btn ${activeTab === 'overlay' ? 'btn-accent' : 'btn-secondary'} btn-sm`}
          onClick={() => { setActiveTab('overlay'); loadOverlay(); }}
        >
          ✨ Overlay Design Space (Sweet Spot)
        </button>
        <button
          className={`btn ${activeTab === 'monte-carlo' ? 'btn-warning' : 'btn-secondary'} btn-sm`}
          onClick={() => { setActiveTab('monte-carlo'); loadMonteCarlo(); }}
        >
          🎲 Monte Carlo Robustness Heatmap
        </button>
      </div>

      {/* Response + factor selectors */}
      <div className="card mb-2">
        <div style={{ display:'flex', gap:'1.5rem', flexWrap:'wrap', alignItems:'end' }}>
          {activeTab === 'contour' && (
            <div className="form-group" style={{ minWidth:'180px' }}>
              <label className="form-label">Response</label>
              <select className="form-select" value={selResp} onChange={e=>setSelResp(+e.target.value)}>
                {responses.map((r:any,i:number) => <option key={i} value={i}>{r.name}</option>)}
              </select>
            </div>
          )}
          <div className="form-group" style={{ minWidth:'180px' }}>
            <label className="form-label">Factor X (horizontal)</label>
            <select className="form-select" value={factX} onChange={e=>setFactX(+e.target.value)}>
              {factors.map((f:any,i:number) => <option key={i} value={i}>{f.name}</option>)}
            </select>
          </div>
          <div className="form-group" style={{ minWidth:'180px' }}>
            <label className="form-label">Factor Y (vertical)</label>
            <select className="form-select" value={factY} onChange={e=>setFactY(+e.target.value)}>
              {factors.map((f:any,i:number) => <option key={i} value={i}>{f.name}</option>)}
            </select>
          </div>
        </div>
      </div>

      {activeTab === 'contour' && (
        <div className="grid-2" style={{ gap:'1.25rem' }}>
          {/* Contour heatmap (simulated via Scatter) */}
          {contour && contour.grid && Array.isArray(contour.grid) ? (
            <div className="chart-wrap">
              <div className="chart-title">
                Response Contour: {responses[selResp]?.name} as a function of {factors[factX]?.name} vs {factors[factY]?.name}
              </div>
              {(() => {
                const pts: any[] = []
                contour.grid.forEach((row: number[], xi: number) => {
                  if (Array.isArray(row)) {
                    row.forEach((z: number, yi: number) => {
                      pts.push({ x: contour.x_actual?.[xi], y: contour.y_actual?.[yi], z })
                    })
                  }
                })
                return (
                  <ResponsiveContainer width="100%" height={280}>
                    <ScatterChart margin={{ top:10, right:20, bottom:20, left:20 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                      <XAxis dataKey="x" name={factors[factX]?.name} type="number" domain={['auto','auto']} tick={{ fill:'var(--text-muted)', fontSize:9 }} label={{ value:factors[factX]?.name, position:'insideBottom', fill:'var(--text-secondary)', fontSize:10, offset:-5 }} />
                      <YAxis dataKey="y" name={factors[factY]?.name} type="number" domain={['auto','auto']} tick={{ fill:'var(--text-muted)', fontSize:9 }} label={{ value:factors[factY]?.name, angle:-90, position:'insideLeft', fill:'var(--text-secondary)', fontSize:10 }} />
                      <ZAxis dataKey="z" range={[20,80]} />
                      <Tooltip cursor={{ strokeDasharray:'3 3' }} content={({ active, payload }) => active && payload?.length ? (
                        <div style={{ background:'var(--bg-elevated)', border:'1px solid var(--border)', borderRadius:8, padding:'0.5rem 0.75rem', fontSize:'0.78rem' }}>
                          <div>{factors[factX]?.name}: <strong>{payload[0]?.payload?.x?.toFixed(3)}</strong></div>
                          <div>{factors[factY]?.name}: <strong>{payload[0]?.payload?.y?.toFixed(3)}</strong></div>
                          <div style={{ color:'var(--accent)' }}>{responses[selResp]?.name}: <strong>{payload[0]?.payload?.z?.toFixed(3)}</strong></div>
                        </div>
                      ) : null} />
                      <Scatter data={pts} fill="var(--primary)" opacity={0.7} />
                    </ScatterChart>
                  </ResponsiveContainer>
                )
              })()}
            </div>
          ) : (
            <div className="chart-wrap flex-center" style={{ minHeight:'280px', padding: '2rem', textAlign: 'center' }}>
              {loading ? <div className="loading-overlay"><div className="spinner"/> Loading…</div> : <div style={{ color:'var(--text-muted)' }}>{contour?.error || 'Run statistical analysis first to generate response contour'}</div>}
            </div>
          )}

          {/* Observed vs Predicted */}
          {obsPred.length > 0 ? (
            <div className="chart-wrap">
              <div className="chart-title">Observed vs. Predicted — {responses[selResp]?.name}</div>
              <ResponsiveContainer width="100%" height={280}>
                <ScatterChart margin={{ top:10, right:20, bottom:20, left:20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                  <XAxis dataKey="predicted" name="Predicted" type="number" domain={['auto','auto']} tick={{ fill:'var(--text-muted)', fontSize:9 }} label={{ value:'Predicted', position:'insideBottom', fill:'var(--text-secondary)', fontSize:10, offset:-5 }} />
                  <YAxis dataKey="observed"  name="Observed"  type="number" domain={['auto','auto']} tick={{ fill:'var(--text-muted)', fontSize:9 }} label={{ value:'Observed', angle:-90, position:'insideLeft', fill:'var(--text-secondary)', fontSize:10 }} />
                  <ZAxis range={[40,40]} />
                  <Tooltip cursor={{ strokeDasharray:'3 3' }} />
                  <Scatter data={obsPred} fill="var(--success)" opacity={0.85} />
                  <ReferenceLine stroke="rgba(99,102,241,0.5)" strokeDasharray="5 5" segment={[{ x:Math.min(...obsPred.map(d=>d.predicted)), y:Math.min(...obsPred.map(d=>d.predicted)) },{ x:Math.max(...obsPred.map(d=>d.predicted)), y:Math.max(...obsPred.map(d=>d.predicted)) }]} />
                </ScatterChart>
              </ResponsiveContainer>
              {rsm && <div style={{ textAlign:'center', fontSize:'0.78rem', color:'var(--text-muted)', marginTop:'0.5rem' }}>R² = {rsm.R2} · R²adj = {rsm.R2_adj}</div>}
            </div>
          ) : (
            <div className="chart-wrap flex-center" style={{ minHeight:'280px', color:'var(--text-muted)' }}>No prediction data available</div>
          )}
        </div>
      )}

      {/* Overlay Design Space View */}
      {activeTab === 'overlay' && (
        <div className="card" style={{ padding: '1.25rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <h3 style={{ fontSize: '1rem', fontWeight: 700, margin: 0, color: 'var(--accent)' }}>
              ICH Q8(R2) Overlay Design Space Plot (Feasible Sweet Spot)
            </h3>
            <span className="badge badge-accent">Superimposed Response Boundaries</span>
          </div>

          {loadingOverlay ? (
            <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
              Calculating superimposed response boundaries across multi-response specifications...
            </div>
          ) : overlayData && overlayData.sweet_spot_grid && Array.isArray(overlayData.sweet_spot_grid) ? (
            <div>
              {(() => {
                const pts: any[] = []
                overlayData.sweet_spot_grid.forEach((row: number[], xi: number) => {
                  if (Array.isArray(row)) {
                    row.forEach((status: number, yi: number) => {
                      pts.push({
                        x: overlayData.x_actual?.[xi],
                        y: overlayData.y_actual?.[yi],
                        isSweetSpot: status === 1
                      })
                    })
                  }
                })
                const sweetPts = pts.filter(p => p.isSweetSpot)
                const failPts = pts.filter(p => !p.isSweetSpot)

                return (
                  <div>
                    <ResponsiveContainer width="100%" height={320}>
                      <ScatterChart margin={{ top:10, right:20, bottom:20, left:20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                        <XAxis dataKey="x" name={factors[factX]?.name} type="number" domain={['auto','auto']} tick={{ fill:'var(--text-muted)', fontSize:9 }} label={{ value: factors[factX]?.name, position: 'insideBottom', offset: -5, fill: 'var(--text-secondary)', fontSize: 10 }} />
                        <YAxis dataKey="y" name={factors[factY]?.name} type="number" domain={['auto','auto']} tick={{ fill:'var(--text-muted)', fontSize:9 }} label={{ value: factors[factY]?.name, angle: -90, position: 'insideLeft', fill: 'var(--text-secondary)', fontSize: 10 }} />
                        <ZAxis range={[30, 30]} />
                        <Tooltip />
                        <Scatter name="Violates Specs" data={failPts} fill="rgba(239,68,68,0.4)" />
                        <Scatter name="Design Space Sweet Spot" data={sweetPts} fill="var(--success-light)" />
                      </ScatterChart>
                    </ResponsiveContainer>
                    <div style={{ display: 'flex', gap: '1.5rem', justifyContent: 'center', fontSize: '0.8rem', marginTop: '0.5rem' }}>
                      <span style={{ color: 'var(--success-light)', fontWeight: 700 }}>■ Design Space (Meets All Specifications)</span>
                      <span style={{ color: 'var(--danger-light)' }}>■ Out of Specification Region</span>
                    </div>
                  </div>
                )
              })()}
            </div>
          ) : (
            <div style={{ color: 'var(--text-muted)', padding: '2rem', textAlign: 'center' }}>
              {overlayData?.error || 'Run regression analysis on all responses to view the overlay plot.'}
            </div>
          )}
        </div>
      )}

      {/* Monte Carlo Robustness View */}
      {activeTab === 'monte-carlo' && (
        <div className="card" style={{ padding: '1.25rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <h3 style={{ fontSize: '1rem', fontWeight: 700, margin: 0, color: 'var(--warning-light)' }}>
              Monte Carlo Robustness Heatmap (Probability of Success)
            </h3>
            <span className="badge badge-warning">5,000 Stochastic Iterations</span>
          </div>

          {loadingMC ? (
            <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--text-muted)' }}>
              Propagating factor standard deviations through RSM models across 5,000 iterations per grid point...
            </div>
          ) : monteCarloData && monteCarloData.prob_heatmap && Array.isArray(monteCarloData.prob_heatmap) ? (
            <div>
              {(() => {
                const pts: any[] = []
                monteCarloData.prob_heatmap.forEach((row: number[], xi: number) => {
                  if (Array.isArray(row)) {
                    row.forEach((prob: number, yi: number) => {
                      pts.push({
                        x: monteCarloData.x_actual?.[xi],
                        y: monteCarloData.y_actual?.[yi],
                        prob
                      })
                    })
                  }
                })

                return (
                  <div>
                    <ResponsiveContainer width="100%" height={320}>
                      <ScatterChart margin={{ top:10, right:20, bottom:20, left:20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                        <XAxis dataKey="x" name={factors[factX]?.name} type="number" domain={['auto','auto']} tick={{ fill:'var(--text-muted)', fontSize:9 }} label={{ value: factors[factX]?.name, position: 'insideBottom', offset: -5, fill: 'var(--text-secondary)', fontSize: 10 }} />
                        <YAxis dataKey="y" name={factors[factY]?.name} type="number" domain={['auto','auto']} tick={{ fill:'var(--text-muted)', fontSize:9 }} label={{ value: factors[factY]?.name, angle: -90, position: 'insideLeft', fill: 'var(--text-secondary)', fontSize: 10 }} />
                        <ZAxis dataKey="prob" range={[20, 100]} />
                        <Tooltip content={({ active, payload }) => active && payload?.length ? (
                          <div style={{ background:'var(--bg-elevated)', border:'1px solid var(--border)', borderRadius:8, padding:'0.5rem 0.75rem', fontSize:'0.78rem' }}>
                            <div>{factors[factX]?.name}: <strong>{payload[0]?.payload?.x?.toFixed(3)}</strong></div>
                            <div>{factors[factY]?.name}: <strong>{payload[0]?.payload?.y?.toFixed(3)}</strong></div>
                            <div style={{ color:'var(--warning-light)', fontWeight: 700 }}>Probability of Success: {payload[0]?.payload?.prob}%</div>
                          </div>
                        ) : null} />
                        <Scatter data={pts} fill="var(--warning)" opacity={0.8} />
                      </ScatterChart>
                    </ResponsiveContainer>
                  </div>
                )
              })()}
            </div>
          ) : (
            <div style={{ color: 'var(--text-muted)', padding: '2rem', textAlign: 'center' }}>
              {monteCarloData?.error || 'Run regression analysis on all responses to evaluate Monte Carlo robustness.'}
            </div>
          )}
        </div>
      )}

      {/* Diagnostics */}
      {diag && (
        <div className="card mt-2">
          <div className="card-title mb-2">Model Diagnostics</div>
          <div className="grid-4">
            {[{l:'RMSE', v:diag.RMSE},{l:'MAE', v:diag.MAE},{l:'Shapiro-Wilk p', v:diag.shapiro_p},{l:'Normality', v:diag.normality_ok?'✓ OK':'⚠ Check'}].map(s=>(
              <div key={s.l} className="stat-card">
                <div className="stat-label">{s.l}</div>
                <div className="stat-value" style={{ fontSize:'1rem', color: s.l==='Normality'&&s.v==='✓ OK'?'var(--success)':s.l==='Normality'?'var(--warning)':'var(--text-primary)' }}>{typeof s.v==='number'?s.v.toFixed(4):s.v}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="step-nav">
        <button className="btn btn-secondary" onClick={() => setStep('statistical-analysis')}>← Back</button>
        <button className="btn btn-primary" onClick={() => setStep('initial-optimization')}>
          Proceed to Optimization →
        </button>
      </div>
    </div>
  )
}

